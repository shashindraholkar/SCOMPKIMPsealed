# SCOM-PKICertificateMP
This is for SCOM - System Center Operations Manager: The PKI Certificate Verification MP discovers PKI Certificates and Certificate Revocation Lists inside computers’ local certificate stores. It helps preventing service interruptions caused by invalid certificates by alerting when

#Build
Works best when using Visual Studio Authoring Extensions.
